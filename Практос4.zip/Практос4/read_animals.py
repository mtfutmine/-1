import csv
forest_animals = []
with open('animals.csv', 'r', encoding='utf-8') as csvfile:
    reader = csv.reader(csvfile)
    headers = next(reader)
    for row in reader:
        animal = row[0]
        habitat = row[1]
        if habitat == 'Лес':
            forest_animals.append(animal)
print("Животные, обитающие в Лесу:")
for animal in forest_animals:
    print(animal)
import csv
data = [
    ['Животное', 'Среда_обитания'],
    ['Медведь', 'Лес'],
    ['Дельфин', 'Океан'],
    ['Верблюд', 'Пустыня']
]
with open('animals.csv', 'w', newline='', encoding='utf-8') as csvfile:
    writer = csv.writer(csvfile)
    writer.writerows(data)
print("Файл animals.csv успешно создан")
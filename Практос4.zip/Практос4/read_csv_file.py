import csv
try:
    with open('csv_file.csv', 'r', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            try:
                age = int(row['Возраст'])
                if age > 30:
                    print(row['Имя'])
            except (ValueError, KeyError):
                continue
except FileNotFoundError:
    print("Файл не найден")
import os
import random

def sozdat_direktoriyu():
    if not os.path.exists("statistics"):
        os.makedirs("statistics")

def sohranit_statistiku(rezhim, pobeditel):
    filename = os.path.join("statistics", f"{rezhim}.txt")
    with open(filename, "a") as f:
        f.write(f"Победитель: {pobeditel}")

def otobrazit_pole(pole):
    print("  " + ".".join(str(i+1) for i in range(len(pole))))
    
    for i, row in enumerate(pole):
        print(f"{i+1} " + ".".join(row))
    
    print()

def proverit_pobedu(pole, simvol):
    for row in pole:
        if all(cell == simvol for cell in row):
            return True
    
    for col in range(len(pole)):
        if all(pole[row][col] == simvol for row in range(len(pole))):
            return True
    
    if all(pole[i][i] == simvol for i in range(len(pole))):
        return True
    
    if all(pole[i][len(pole) - 1 - i] == simvol for i in range(len(pole))):
        return True
    
    return False

def proverit_pat(pole):
    return all(cell != " " for row in pole for cell in row)

def hod_igroka(pole, simvol):
    while True:
        try:
            row = int(input(f"Введите номер строки (1-{len(pole)}) для {simvol}: ")) - 1
            col = int(input(f"Введите номер столбца (1-{len(pole)}) для {simvol}: ")) - 1

            if 0 <= row < len(pole) and 0 <= col < len(pole) and pole[row][col] == " ":
                pole[row][col] = simvol
                return
            else:
                print("Недопустимый ход. Попробуйте еще раз.")
        except ValueError:
            print("Некорректный ввод. Введите числовые значения.")

def hod_robota(pole, simvol):
    dostupnye_hody = []
    for row in range(len(pole)):
        for col in range(len(pole)):
            if pole[row][col] == " ":
                dostupnye_hody.append((row, col))

    if dostupnye_hody:
        row, col = random.choice(dostupnye_hody)
        pole[row][col] = simvol
        print(f"Робот ходит: строка {row + 1}, столбец {col + 1}")
    else:
        print("Нет доступных ходов для робота.")

def igra(razmer_polya, rezhim):
    pole = [[" " for _ in range(razmer_polya)] for _ in range(razmer_polya)]
    igrok_1 = "X"
    igrok_2 = "O"

    tekushiy_igrok = random.choice([igrok_1, igrok_2])
    print(f"Первым ходит игрок {tekushiy_igrok}")
    print()

    while True:
        otobrazit_pole(pole)

        if rezhim == "igrok_protiv_igroka":
            hod_igroka(pole, tekushiy_igrok)
        elif rezhim == "igrok_protiv_robota":
            if tekushiy_igrok == igrok_1:
                hod_igroka(pole, tekushiy_igrok)
            else:
                hod_robota(pole, tekushiy_igrok)

        if proverit_pobedu(pole, tekushiy_igrok):
            otobrazit_pole(pole)
            print(f"Игрок {tekushiy_igrok} победил!")
            sohranit_statistiku(rezhim, tekushiy_igrok)
            return

        if proverit_pat(pole):
            otobrazit_pole(pole)
            print("Пат! Ничья.")
            sohranit_statistiku(rezhim, "Ничья")
            return

        tekushiy_igrok = igrok_2 if tekushiy_igrok == igrok_1 else igrok_1

def main():
    sozdat_direktoriyu()

    while True:
        try:
            razmer_polya = int(input("Введите размер игрового поля (например, 3 для поля 3x3): "))
            if razmer_polya <= 0:
                print("Размер поля должен быть положительным числом.")
                continue
        except ValueError:
            print("Некорректный ввод. Введите числовое значение.")
            continue

        rezhim = input("Выберите режим игры (игрок_против_игрока или игрок_против_робота): ")
        if rezhim not in ["igrok_protiv_igroka", "igrok_protiv_robota"]:
            print("Некорректный режим игры. Попробуйте еще раз.")
            continue

        igra(razmer_polya, rezhim)

        novaya_igra = input("Хотите сыграть еще раз? (да/нет): ")
        if novaya_igra.lower() != "да":
            break

if __name__ == "__main__":
    main()